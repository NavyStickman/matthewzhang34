#include "main.h"
#include "pros/motors.h"
// 1 AND 17 ARE BAD

// Drive Motors :: Slide Side is the Front
pros::Motor driveLeftBackB(2,pros::E_MOTOR_GEARSET_06, false, pros::E_MOTOR_ENCODER_COUNTS);
pros::Motor driveLeftBackT(3,pros::E_MOTOR_GEARSET_06, true, pros::E_MOTOR_ENCODER_COUNTS);
pros::Motor driveLeftFront(8,pros::E_MOTOR_GEARSET_06, false, pros::E_MOTOR_ENCODER_COUNTS);

pros::Motor driveRightBackT(5,pros::E_MOTOR_GEARSET_06, true, pros::E_MOTOR_ENCODER_COUNTS);
pros::Motor driveRightBackB(4,pros::E_MOTOR_GEARSET_06, false, pros::E_MOTOR_ENCODER_COUNTS);
pros::Motor driveRightFront(6,pros::E_MOTOR_GEARSET_06, false, pros::E_MOTOR_ENCODER_COUNTS);

// Intake Motors
pros::Motor intakeMotor(7, pros::E_MOTOR_GEARSET_18, false, pros::E_MOTOR_ENCODER_COUNTS);

// Winch Motors
pros::Motor winchMotor(10, pros::E_MOTOR_GEARSET_36, false, pros::E_MOTOR_ENCODER_DEGREES);

// Expansion
pros::ADIDigitalOut expand('B');
bool digitalRead (3);

//controller
pros::Imu rotat(15);

pros::Controller controller(pros::E_CONTROLLER_MASTER);