#include "main.h"

extern pros::Motor driveLeftBackT;
extern pros::Motor driveLeftBackB;
extern pros::Motor driveLeftFront;
extern pros::Motor driveRightBackT;
extern pros::Motor driveRightBackB;
extern pros::Motor driveRightFront;
extern pros::Motor winchMotor;
extern pros::Motor intakeMotor;

extern pros::ADIDigitalOut expand;

//controller
extern pros::Controller controller;

extern pros::Imu rotat;
//misc
