#include "main.h"
#include "pros/adi.h"
#include "pros/adi.hpp"
#include "pros/misc.h"
#include <iostream>

/**
 * A callback function for LLEMU's center button.
 *
 * When this callback is fired, it will toggle line 2 of the LCD text between
 * "I was pressed!" and nothing.
 */
 pros::ADIDigitalOut Latch('C');
void on_center_button() {
	static bool pressed = false;
	pressed = !pressed;
	if (pressed) {
		pros::lcd::set_text(2, "I was pressed!");
	} else {
		pros::lcd::clear_line(2);
	}
}

/**
 * Runs initialization code. This occurs as soon as the program is started.
 *
 * All other competition modes are blocked by initialize; it is recommended
 * to keep execution time for this mode under a few seconds.
 */
 
	pros::ADIDigitalIn sensor ('C');
void initialize() {
	pros::lcd::initialize();
	pros::lcd::set_text(1, "Hello PROS User!");

	pros::lcd::register_btn1_cb(on_center_button);


	//rotat.reset();
	pros::delay(300);

}

/**
 * Runs while the robot is in the disabled state of Field Management System or
 * the VEX Competition Switch, following either autonomous or opcontrol. When
 * the robot is enabled, this task will exit.
 */
void disabled() {}

/**
 * Runs after initialize(), and before autonomous when connected to the Field
 * Management System or the VEX Competition Switch. This is intended for
 * competition-specific initialization routines, such as an autonomous selector
 * on the LCD.
 *
 * This task will exit when the robot is enabled and autonomous or opcontrol
 * starts.
 */
void competition_initialize() {}

/**
 * Runs the user autonomous code. This function will be started in its own task
 * with the default priority and stack size whenever the robot is enabled via
 * the Field Management System or the VEX Competition Switch in the autonomous
 * mode. Alternatively, this function may be called in initialize or opcontrol
 * for non-competition testing purposes.
 *
 * If the robot is disabled or communications is lost, the autonomous task
 * will be stopped. Re-enabling the robot will restart the task, not re-start it
 * from where it left off.
 */
void autonomous() {

	
	//intakeMotor1.move_relative(295, 
	//120);
	//intakeMotor2.move_relative(-295, 
	//120);
		//pros::delay(5000);

//	setDrive(20,-20);

	//setWinch(1600)


// translate(time(ms),power)
//rotate(unitstime, power, postive goes right during turning.)

	translate(300, 80);

	//go back into the roller
	// intakeMotor1.move_relative(295, 120);
	intakeMotor.move_relative(120, 120);
	pros::delay(1000);
	translate(500, -20);
	// rolley roller

	//rotate(90,1);
	//translate(5500, 50);

	//setWinch(2510);

			expand.set_value(true);
/*





	translate(800, 25);
	rotate(90,1);
	translate(2500, 25);
	rotate(90,1);
		translate(300, 80);
	//go back into the roller
	// intakeMotor1.move_relative(295, 120);
	intakeMotor.move_relative(120, 120);
	pros::delay(1000);
	translate(500, -20);



*/




	//end:
	expand.set_value(0);

	setDrive(0,0);
}



/**
 * Runs the operator control code. This function will be started in its own task
 * with the default priority and stack size whenever the robot is enabled via
 * the Field Management System or the VEX Competition Switch in the operator
 * control mode.
 *
 * If no competition control is connected, this function will run immediately
 * following initialize().
 *
 * If the robot is disabled or communications is lost, the
 * operator control task will be stopped. Re-enabling the robot will restart the
 * task, not resume it from where it left off.
 */
int intake = 0;
bool intaketoggle = false;
bool reversed = false;
bool shoottoggle = true;
bool expanded = false;
bool winchdown = false;
float counter =0,rewind_=0;

bool intakeallowed= false;
void opcontrol() {

	while(true){

		setDriveMotors();

		// Turns intake on
		if(controller.get_digital_new_press(pros::E_CONTROLLER_DIGITAL_L1)){
			std::cout << "L1 was pressed" << std::endl;
			intaketoggle = !intaketoggle;
		}

		if(intaketoggle == true ){
			setIntake(127);

		} else if(intaketoggle == false){
			std::cout << "else statement run" << std::endl;
			setIntake(0);
		}
		
		// Reverses Intake
		if(controller.get_digital_new_press(pros::E_CONTROLLER_DIGITAL_L2)){
			setIntake(-127);
			
			pros::delay(1000);
		}

		// Winding the Winch backwards
		if(controller.get_digital(pros::E_CONTROLLER_DIGITAL_R2)){
			counter =0;
			counter =winchMotor.get_position();
			
			winchMotor.set_brake_mode(pros::E_MOTOR_BRAKE_COAST);
			winchMotor.move(127);
			pros::delay(200);
		}
/*

		if(controller.get_digital(pros::E_CONTROLLER_DIGITAL_R2) ){
			shoottoggle = !shoottoggle;
			winchMotor.move(0);
			pros::delay(200);
		}
*/
		// Shooting the winch
		if(controller.get_digital(pros::E_CONTROLLER_DIGITAL_R1)){
			Latch.set_value(false);
		}

		if(sensor.get_value()){
			Latch.set_value(true);
			rewind_ = fabs(winchMotor.get_position() - counter);

			std::cout << "Obama";
			winchMotor.set_brake_mode(pros::E_MOTOR_BRAKE_COAST);
			winchMotor.move(0);
				// shoottoggle = !shoottoggle;
			winchdown = !winchdown;
			winchMotor.set_brake_mode(pros::E_MOTOR_BRAKE_COAST);
			
			winchMotor.move_relative(-rewind_,127);
		}


		if(controller.get_digital(pros::E_CONTROLLER_DIGITAL_X)){
			winchMotor.set_brake_mode(pros::E_MOTOR_BRAKE_COAST);
			//setWinch(-910);
		   winchMotor.move(0);
			winchMotor.move_relative(-60,127);
				winchMotor.set_brake_mode(pros::E_MOTOR_BRAKE_COAST);


		
			pros::delay(300);
						winchMotor.set_brake_mode(pros::E_MOTOR_BRAKE_COAST);
		}

		if(controller.get_digital_new_press(pros::E_CONTROLLER_DIGITAL_DOWN)){

			expanded = !expanded;
			expand.set_value(expanded);

		}


		pros::delay(20);

	}
}