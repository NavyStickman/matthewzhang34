#include "main.h"
#include "pros/motors.h"
// 1 AND 17 ARE BAD

// Drive Motors :: Slide Side is the Front
pros::Motor driveLeftBackB(16,pros::E_MOTOR_GEARSET_06, false, pros::E_MOTOR_ENCODER_COUNTS);
pros::Motor driveLeftBackT(20,pros::E_MOTOR_GEARSET_06, true, pros::E_MOTOR_ENCODER_COUNTS);
pros::Motor driveLeftFront(19,pros::E_MOTOR_GEARSET_06, false, pros::E_MOTOR_ENCODER_COUNTS);

pros::Motor driveRightBackT(8,pros::E_MOTOR_GEARSET_06, false, pros::E_MOTOR_ENCODER_COUNTS);
pros::Motor driveRightBackB(3,pros::E_MOTOR_GEARSET_06, true, pros::E_MOTOR_ENCODER_COUNTS);
pros::Motor driveRightFront(10,pros::E_MOTOR_GEARSET_06, false, pros::E_MOTOR_ENCODER_COUNTS);

// Intake Motors
pros::Motor intakeMotor(5, pros::E_MOTOR_GEARSET_18, false, pros::E_MOTOR_ENCODER_COUNTS);

// Winch Motors
pros::Motor winchMotor(11, pros::E_MOTOR_GEARSET_36, true, pros::E_MOTOR_ENCODER_DEGREES);

// Expansion
pros::ADIDigitalOut expand('B');
//pros::ADIDigitalOut Latch('C');
bool digitalRead (3);

//controller
pros::Imu rotat(15);

pros::Controller controller(pros::E_CONTROLLER_MASTER);